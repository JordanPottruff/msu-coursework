require '../ruby_lab'

RSpec.describe "Title Cleaned" do
  context "When no cleaning required" do

  end

  context "When there are brackets () [] {}" do

  end

  context "When there are \\ / _ - : \" ` + = * or feat." do

  end

  context "When there is punctuation" do

  end

  context "When there is non-english characters" do

  end
end
